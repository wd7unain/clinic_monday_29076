package com.abdalla.clinic.Service;

import com.abdalla.clinic.Entities.Appointment;
import com.abdalla.clinic.Repository.AppointmentRepository;
import com.abdalla.clinic.Repository.DoctorRepository;
import com.abdalla.clinic.Repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AppointmentService {
    @Autowired
    AppointmentRepository appointmentRepo ;

    @Autowired
    DoctorRepository doctorRepo ;

    @Autowired
    PatientRepository patientRepo ;

    public String saveAppointment(Appointment app , Long doctorId , Long patientId){
        if (doctorRepo.existsById(doctorId) && patientRepo.existsById(patientId)) {
            app.setDoctor(doctorRepo.findById(doctorId).orElse(null));
            app.setPatient(patientRepo.findById(patientId).orElse(null));
        }else {

            return "doctor or patient is not exist please try again with a valid id  ";
        }
        if(app != null) {
            appointmentRepo.save(app);
            return "saved";
        }


        return "app can't be null";
    }
}
