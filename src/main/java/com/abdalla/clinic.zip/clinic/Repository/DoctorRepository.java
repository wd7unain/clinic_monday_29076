package com.abdalla.clinic.Repository;

import com.abdalla.clinic.Entities.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    Doctor findDoctorById(long id);

    Doctor findDoctorByName(String name);

    boolean existsByOfficeId(Long id);

}
