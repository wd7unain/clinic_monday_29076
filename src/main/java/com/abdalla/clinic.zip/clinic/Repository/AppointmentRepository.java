package com.abdalla.clinic.Repository;

import com.abdalla.clinic.Entities.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment , Long > {
}
