package com.abdalla.clinic.Repository;

import com.abdalla.clinic.Entities.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientRepository extends JpaRepository<Patient , Long> {
    Patient findPatientById(long id);
}
