package com.abdalla.clinic.Controller;

import com.abdalla.clinic.Entities.Appointment;
import com.abdalla.clinic.Service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/appointment")
public class AppointmentController {
    @Autowired
    private AppointmentService appService ;

    public String saveAppointment(@RequestBody Appointment app , @RequestParam Long doctorId , @RequestParam Long patientId){
        appService.saveAppointment(app ,doctorId ,patientId) ;
        return "saved";
    }
}
